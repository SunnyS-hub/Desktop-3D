﻿using Firebase.Auth;
using Firebase.Storage;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desktop_3D_Viewer_v2__FYP_
{
    public partial class Form1 : Form
    {
        //private static string ApiKey = "AIzaSyBdMq0SBI7l1M6inFv5dZo9r7wj69DdXW4";
        private int fileCounter = 0; 
        private static string Bucket = "desktop3dviewer-fyp.appspot.com";
        //private static string AuthEmail = "hyujikjkjjj@gmail.com";
        //private static string AuthPassword = "3dviewerpass";

        //private FirebaseAuthProvider auth;
        //private FirebaseAuthLink a;
        ScreenCapture sc; 
        //CancellationTokenSource cancellation;
        
        public Form1()
        {
            InitializeComponent();
            init();
        }

        private  void init()
        {
            //cancellation = new CancellationTokenSource();
            sc = new ScreenCapture();
        }

        private void send_to_firestore_btn(object sender, EventArgs e)
        {
            Stream.Start();
           
            
        }
        public static async void Upload(int currentCounter, byte[] bitmapMemBytes)
        {
            try
            {
                MemoryStream stream = new MemoryStream(bitmapMemBytes);
                var task = await new FirebaseStorage(
                Bucket,
                new FirebaseStorageOptions
                {
                    //AuthTokenAsyncFactory = () => Task.FromResult(a.FirebaseToken),
                    //ThrowOnCancel = true // when you cancel the upload, exception is thrown. By default no exception is thrown
                })
                .Child("Frames")
                .Child("frame" + currentCounter + ".jpeg")
                .PutAsync(stream);
            }
            catch(Exception e)
            {
                Console.WriteLine("File Missing");
                Console.WriteLine(e);
            }
            if(currentCounter % 35 == 0)
                GC.Collect();
        }

        private void timer_tick(object sender, EventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            
            sc.CaptureScreenToFile(fileCounter, pointer.Checked);
            //Task.Run(() => { Upload(fileCounter); });
            fileCounter++;
            Console.WriteLine("Time Elapsed for uploading frame: " + sw.ElapsedMilliseconds  + "ms , fileCount Value: " + fileCounter );
        }

        private void StopStream(object sender, EventArgs e)
        {
            fileCounter = 0;
            Stream.Stop();    
        }

        private void IncludeMouse(object sender, EventArgs e)
        {
           
                Console.WriteLine(pointer.Checked);

        }

        private void ExitApplication()
        {
            Stream.Stop();
            Application.Exit();
        }

        private void ApplicationClose(object sender, FormClosingEventArgs e)
        {
            ExitApplication();
        }

        private void close_btn(object sender, EventArgs e)
        {
            ExitApplication();
        }
    }
}
