package com.example.desktop3dviewer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private StorageReference storageRef;
    private ImageView imageView1;
    private ImageView imageView2;
    private TextView counterView;
    private TextView imgDepthLbl;
    private SeekBar seekBar;
    private Handler imgHandler = new Handler();
    private int fileCounter = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        imageView1 = (ImageView) findViewById(R.id.imageView);
        imageView2 = (ImageView) findViewById(R.id.imageView2);

        seekBar = (SeekBar) findViewById(R.id.viewDepth);
        imgDepthLbl = (TextView) findViewById(R.id.viewDepthLabel);
        counterView = (TextView) findViewById(R.id.fileCounter);

        imageView1.setImageResource(R.drawable.dark_placeholder);
        imageView2.setImageResource(R.drawable.dark_placeholder);

        imgRunnable.run();

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                imageView1.setScrollX(-1*progress);
                imageView2.setScrollX(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
    private boolean skip = false;
    private void getFrame(){
        counterView.setText(String.format("FileCount: %d", fileCounter));


        storageRef = FirebaseStorage.getInstance().getReference().child("Frames")
                .child("frame" + fileCounter + ".jpeg");
        try {
            File local = File.createTempFile("frame", "jpeg");
            storageRef.getFile(local)
                    .addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                            skip = false;
                            Bitmap bitmap = BitmapFactory.decodeFile(local.getAbsolutePath());
                            imageView1.setImageBitmap(bitmap);
                            imageView2.setImageBitmap(bitmap);
                            fileCounter++;
                            storageRef.delete();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    //Toast.makeText(MainActivity.this, "Retrival failed", Toast.LENGTH_SHORT).show();
                    if(fileCounter != 0) {
                        try {
                            Thread.sleep(100);

                        } catch (InterruptedException interruptedException) {
                            interruptedException.printStackTrace();
                        }
                        if(skip){
                            fileCounter++;
                            skip = false;
                        }
                        skip = true;
                    }
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    private Runnable imgRunnable = new Runnable() {

        @Override
        public void run() {
            getFrame();
            imgHandler.postDelayed(imgRunnable, 250);
        }
    };

    public void showSeekBar(View view) {
        if(seekBar.getVisibility() == View.INVISIBLE) {
            seekBar.setVisibility(View.VISIBLE);
            imgDepthLbl.setVisibility(View.VISIBLE);
        }else{
            seekBar.setVisibility(View.INVISIBLE);
            imgDepthLbl.setVisibility(View.INVISIBLE);
        }

    }
}