﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;
using ScreenCap;

namespace TestADBConnection
{
    public partial class Form1 : Form
    {

        private static int fileCounter = 0;
        int screenWidth = 1600;
        int screenHeight = 1200;
        ScreenCapture sc;
        //public static Image image;
        public Form1(){
            InitializeComponent();
            ProcessStartInfo ps = new ProcessStartInfo("cmd");
            ps.WindowStyle = ProcessWindowStyle.Hidden;
            ps.Arguments = @"/k adb shell am start -c api.android.intent.LAUNCHER -a" + " " +
                "api.android.category.MAIN -n com.example.myapplication/" +
                "com.example.myapplication.MainActivity";
            Process.Start(ps);

        }
        static ProcessStartInfo ps = new ProcessStartInfo("cmd");


        public static void UploadFrame(int currentCounter)
        {
            //ps.WindowStyle = ProcessWindowStyle.Hidden;
            ps.CreateNoWindow = true;
            ps.UseShellExecute = false;
            ps.Arguments = @"/k adb push " + Application.StartupPath + @"\Imgs\f" + currentCounter + ".jpg" + " /sdcard/_Frames/frame" + currentCounter + ".jpg";
            Process.Start(ps);
            
        }

        private void StreamScreen(int W, int H)
        {

            
            sc.CaptureScreenToFile(Application.StartupPath + @"\Imgs\f" + (fileCounter) + ".jpg", pointer.Checked);
            Task.Run(() => { UploadFrame(fileCounter); });


            //sc.CaptureScreenToFile(Application.StartupPath + @"\Imgs\f" + fileCount + ".jpg", System.Drawing.Imaging.ImageFormat.Jpeg, false);
            //Task.Run(() => { UploadFrame(); });
            //sc.CaptureScreenToFile(Application.StartupPath + @"\Imgs\f" + fileCount + ".jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
            //Task.Run(() => { UploadFrame(); });

            //Bitmap DesktopBitmap = new Bitmap(W, H);
            //Graphics g = Graphics.FromImage(DesktopBitmap);
            //g.CopyFromScreen(0, 0, 0, 0, new Size(W, H), CopyPixelOperation.SourceCopy);
            ////if (ShowCursor)
            ////Cursors.Default.Draw(g, new Rectangle(Cursor.Position, new Size(32, 32)));
            //g.Dispose();

            ////DesktopBitmap.Save(Application.StartupPath + @"\Imgs\f1.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
            ////Image ScaledBitmap = DesktopBitmap.GetThumbnailImage(W, H, null/* TODO Change to default(_) if this is not a reference type */, IntPtr.Zero);

            ////image = ScaledBitmap;
            //try
            //{
            //    DesktopBitmap.Save(Application.StartupPath + @"\Imgs\f" + fileCount + ".png", System.Drawing.Imaging.ImageFormat.Png);
            //    fileCount++;
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine("Save Error!");
            //    //Console.WriteLine($"Current Thread is {Thread.CurrentThread.ManagedThreadId}");

            //}
            //finally
            //{
            //    DesktopBitmap.Dispose();
            //}



            ////ScaledBitmap.Dispose();
            ////ProcessStartInfo ps = new ProcessStartInfo("cmd");

            ////ps.WindowStyle = ProcessWindowStyle.Hidden;

            ////ps.Arguments = @"/k adb push " + Application.StartupPath + @"\Imgs\f1.jpg" + " /sdcard/Winter" + fileCount + ".jpg";
            ////Process.Start(ps);

        }

        private void screenshot_btn_Click(object sender, EventArgs e)
        {
            sc = new ScreenCapture();
            Stream.Start();
                
        }

        private void PersistantConnectionCheck()
        {
            if (!IsAndroidAppLive("<your_Android_Application_Name>"))
            {
                MessageBox.Show("Stream ended!\nAndroid application is not responding.", "Response error",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Stream.Stop();
                fileCounter = 0; 
            }
        }

        public Boolean IsAndroidAppLive(string applcationName)
        {
            ProcessStartInfo ps = new ProcessStartInfo("cmd");
            ps.CreateNoWindow = true;
            ps.UseShellExecute = false;
            ps.RedirectStandardInput = true;
            ps.RedirectStandardOutput = true;
            var push_output = Process.Start(ps);
            push_output.StandardInput.WriteLine(@"adb shell ps | findstr" + " " + applcationName);
            push_output.StandardInput.Flush();
            push_output.StandardInput.Close();
            push_output.WaitForExit();

            string[] push_rtn = push_output.StandardOutput.ReadToEnd().Split('\n');
            push_output.Dispose();
            //GC.Collect();
            if(push_rtn.Length == 6)
            {
                
                return false;
            }
            else
            {
                return true;
            }

        }

        private void ApplicationClose(object sender, FormClosingEventArgs e)
        {
            ExitApplication();
        }

        public void ExitApplication()
        {
            Stream.Stop();
            Application.Exit();
        }


        Stopwatch sw = new Stopwatch();
        
        private void Stream_Tick(object sender, EventArgs e)
        {
            sw.Restart();
            if (fileCounter % 50 == 0)
            {
                Task.Run(() => { PersistantConnectionCheck(); });
            }
            StreamScreen(screenWidth, screenHeight);
            fileCounter++;
            Console.WriteLine("Time Elapsed for uploading frame: " + sw.ElapsedMilliseconds + "ms , fileCount Value= " + fileCounter);
        }

        private void check_connection_btn(object sender, EventArgs e)
        {
            if (IsAndroidAppLive("myapplication"))
            {
                status_res_label.Text = "Connected";
                status_res_label.ForeColor = Color.Green;
            }
            else
            {
                status_res_label.Text = "Connection Unsuccessful";
                status_res_label.ForeColor = Color.Red;
            }

        }

        private void stop_stream_btn(object sender, EventArgs e)
        {
            fileCounter = 0;
            
            Stream.Stop();
        }

        private void close_app_btn(object sender, EventArgs e)
        {
            ExitApplication();
        }

    }
}
