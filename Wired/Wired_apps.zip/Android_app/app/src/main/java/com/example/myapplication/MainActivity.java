package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    ImageView imageView1;
    ImageView imageView2;
    TextView counterView;
    TextView imgDepthLbl;
    private File file ;
    private File frameFile = new File(Environment.getExternalStorageDirectory(),"/_Frames");;
    private SeekBar seekBar;
    private int fileCounter = 0;
    private boolean syncChecked = false;
    private Handler imgHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_main);
        seekBar = (SeekBar) findViewById(R.id.viewDepth);
        imgDepthLbl = (TextView) findViewById(R.id.viewDepthLabel) ;
        counterView = (TextView) findViewById(R.id.fileCounter);
        imageView1 = (ImageView) findViewById(R.id.imageView);
        imageView2 = (ImageView) findViewById(R.id.imageView2);
        file = new File(Environment.getExternalStorageDirectory(), "/DCIM/abc.jpg");
        //imageView2.setImageURI("https://firebasestorage.googleapis.com/v0/b/desktop3dviewer-fyp.appspot.com/o/testShot1.png?alt=media&token=3d8d3701-8ab1-4e42-92f8-bda085374972");
        imageView1.setImageURI(Uri.fromFile(file));
        imageView2.setImageURI(Uri.fromFile(file));
        if(frameFile.exists()){
            frameFile.delete();
        }
        frameFile.mkdir();
        if(!frameFile.exists()){
            Toast.makeText(getApplicationContext(), "Unable to create temporary file in system -- PLEASE EXIT APP", Toast.LENGTH_LONG).show();

        }

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                imageView1.setScrollX(-1*progress);
                imageView2.setScrollX(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        imgRunnable.run();

    }
//    public void StartThread(View view) {
////            imgHandler.postDelayed(imgRunnable, 5000);
//
//    }
    private boolean skip = false;
    private Runnable imgRunnable = new Runnable() {
        @Override
        public void run() {
            counterView.setText(String.format("FileCount: %d", fileCounter));
            deleteFrame.run();

            file = new File (Environment.getExternalStorageDirectory() +
                    "/_Frames/frame" + fileCounter + ".jpg");

            //counterView.setText("Num Bytes: " + String.valueOf(bm == null));
            if(file.exists()){
                skip = false;
                imageView1.setImageURI(Uri.fromFile(file));
                imageView2.setImageURI((Uri.fromFile(file)));
                fileCounter++;
            }
            else{
                if(fileCounter != 0) {
                    try {
                        Thread.sleep(100);

                    } catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                    if(skip){
                        fileCounter++;
                        skip = false;
                    }else{
                        skip = true;
                    }

                }

            }

            imgHandler.postDelayed(imgRunnable, 250);
        }
    };

    private Runnable deleteFrame = () -> {
        File fileToDelete = new File(Environment.getExternalStorageDirectory(),
                "/_Frames/frame" + (fileCounter - 1) + ".jpg");
        if(fileToDelete.exists()){

            fileToDelete.delete();
        }
    };


    public void showSeekBar(View view) {
        if(seekBar.getVisibility() == View.INVISIBLE) {
            seekBar.setVisibility(View.VISIBLE);
            imgDepthLbl.setVisibility(View.VISIBLE);
        }else{
            seekBar.setVisibility(View.INVISIBLE);
            imgDepthLbl.setVisibility(View.INVISIBLE);
        }

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(frameFile.exists()){
            frameFile.delete();
        }

    }
}

